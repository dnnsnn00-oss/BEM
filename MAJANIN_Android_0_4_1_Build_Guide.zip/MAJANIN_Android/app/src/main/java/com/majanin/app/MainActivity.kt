package com.majanin.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import android.util.Base64
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import org.meshtastic.proto.PortNum
import org.meshtastic.sdk.RadioClient
import org.meshtastic.sdk.storage.sqldelight.SqlDelightStorageProvider
import org.meshtastic.sdk.transport.ble.BleTransport
import com.juul.kable.Peripheral
import com.juul.kable.Scanner
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

class MainActivity : Activity() {
    private lateinit var messages: LinearLayout
    private lateinit var input: EditText
    private lateinit var status: TextView
    private lateinit var memberInfo: TextView
    private lateinit var scroll: ScrollView
    private val purple = Color.rgb(139, 92, 246)
    private val prefs by lazy { getSharedPreferences("majanin_secure_chat", Context.MODE_PRIVATE) }
    private val members = mutableListOf("أنت")
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var scanJob: Job? = null
    private var receiveJob: Job? = null
    private var radioClient: RadioClient? = null
    private var connectedName: String = ""
    private var scanDialog: AlertDialog? = null
    private val foundDevices = linkedMapOf<String, () -> Unit>()
    private val deviceLabels = mutableListOf<String>()
    private lateinit var deviceAdapter: ArrayAdapter<String>
    private val maxMembers = 10

    private fun bg(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = radius.toFloat()
    }
    private fun label(s: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun addMessage(text: String, mine: Boolean, persist: Boolean = false) {
        val bubble = label(text, 16f, Color.WHITE).apply {
            setPadding(dp(16), dp(11), dp(16), dp(11))
            background = bg(if (mine) Color.rgb(92, 55, 160) else Color.rgb(43, 39, 58), dp(22))
            maxWidth = resources.displayMetrics.widthPixels * 4 / 5
        }
        val row = LinearLayout(this).apply {
            gravity = if (mine) Gravity.RIGHT else Gravity.LEFT
            setPadding(dp(8), dp(5), dp(8), dp(5)); addView(bubble)
        }
        messages.addView(row)
        if (persist) saveLocalMessage(text, mine)
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun getOrCreateKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey("majanin_aes_key", null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(KeyGenParameterSpec.Builder(
            "majanin_aes_key", KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        ).setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true).build())
        return generator.generateKey()
    }
    private fun encrypt(plain: String): String {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
        return Base64.encodeToString(cipher.iv + cipher.doFinal(plain.toByteArray(Charsets.UTF_8)), Base64.NO_WRAP)
    }
    private fun decrypt(encoded: String): String? = try {
        val bytes = Base64.decode(encoded, Base64.NO_WRAP)
        val iv = bytes.copyOfRange(0, 12)
        val payload = bytes.copyOfRange(12, bytes.size)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), GCMParameterSpec(128, iv))
        String(cipher.doFinal(payload), Charsets.UTF_8)
    } catch (_: Exception) { null }

    private fun saveLocalMessage(text: String, mine: Boolean) {
        try {
            val old = JSONArray(prefs.getString("messages", "[]"))
            val array = JSONArray()
            // Keep the newest 300 messages so local storage remains bounded.
            val start = (old.length() - 299).coerceAtLeast(0)
            for (i in start until old.length()) array.put(old.getJSONObject(i))
            array.put(JSONObject().put("body", encrypt(text)).put("mine", mine))
            prefs.edit().putString("messages", array.toString()).apply()
        } catch (_: Exception) {
            toast("تعذّر حفظ الرسالة محلياً")
        }
    }
    private fun loadMessages() {
        try {
            val array = JSONArray(prefs.getString("messages", "[]"))
            val start = (array.length() - 300).coerceAtLeast(0)
            for (i in start until array.length()) {
                val item = array.getJSONObject(i)
                decrypt(item.getString("body"))?.let { addMessage(it, item.optBoolean("mine")) }
            }
        } catch (_: Exception) {
            toast("تعذّر قراءة سجل المحادثة؛ يمكنك بدء محادثة جديدة")
        }
    }
    private fun refreshMembers() { memberInfo.text = "غرفة الأصدقاء  |  ${members.size}/$maxMembers أعضاء" }
    private fun loadMembers() {
        val saved = prefs.getString("members", null) ?: return
        try {
            members.clear()
            members.add("أنت")
            val array = JSONArray(saved)
            for (i in 0 until array.length()) {
                val name = array.optString(i).trim()
                if (name.isNotEmpty() && members.size < maxMembers && members.none { it.equals(name, true) }) members.add(name)
            }
        } catch (_: Exception) {
            members.clear()
            members.add("أنت")
        }
    }
    private fun showMembersDialog() {
        val edit = EditText(this).apply { hint = "اسم الصديق"; setSingleLine(true) }
        AlertDialog.Builder(this).setTitle("إضافة صديق")
            .setMessage("هذه قائمة أسماء محلية. يجب أن يكون الأصدقاء على قناة Meshtastic نفسها لاستقبال البث.")
            .setView(edit).setPositiveButton("إضافة") { _, _ ->
                val name = edit.text.toString().trim()
                when {
                    name.isEmpty() -> toast("اكتب اسم الصديق")
                    members.size >= maxMembers -> toast("وصلت المجموعة إلى 10 أعضاء")
                    members.any { it.equals(name, true) } -> toast("هذا الاسم موجود")
                    else -> { members.add(name); prefs.edit().putString("members", JSONArray(members.drop(1)).toString()).apply(); refreshMembers(); toast("أُضيف $name إلى قائمة هذا الهاتف") }
                }
            }.setNegativeButton("إلغاء", null).show()
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    private fun requestBlePermissionsAndScan() {
        val needed = if (Build.VERSION.SDK_INT >= 31) arrayOf(
            Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT
        ).filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
            .filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (needed.isNotEmpty()) requestPermissions(needed.toTypedArray(), 410)
        else startBleScan()
    }

    private fun startBleScan() {
        val adapter = BluetoothAdapter.getDefaultAdapter()
        if (adapter == null) { toast("هذا الهاتف لا يدعم Bluetooth"); return }
        if (!adapter.isEnabled) { toast("فعّل Bluetooth من إعدادات الهاتف أولاً"); return }
        foundDevices.clear(); deviceLabels.clear()
        deviceAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, deviceLabels)
        val list = ListView(this).apply { adapter = deviceAdapter }
        scanDialog = AlertDialog.Builder(this).setTitle("أجهزة Meshtastic القريبة")
            .setView(list).setNegativeButton("إيقاف البحث") { _, _ -> scanJob?.cancel() }.create()
        list.setOnItemClickListener { _, _, position, _ ->
            val action = foundDevices.values.elementAtOrNull(position)
            scanJob?.cancel(); scanDialog?.dismiss(); action?.invoke()
        }
        scanDialog?.setOnDismissListener { scanJob?.cancel() }
        scanDialog?.show()
        scanJob = scope.launch {
            try {
                withTimeout(25_000) {
                    Scanner().advertisements.collect { advertisement ->
                        val name = advertisement.name?.takeIf { it.isNotBlank() } ?: "جهاز Bluetooth بدون اسم"
                        val id = advertisement.identifier.toString()
                        if (!foundDevices.containsKey(id)) {
                            foundDevices[id] = { connectToRadio(advertisement, name) }
                            deviceLabels.add("$name\n$id")
                            deviceAdapter.notifyDataSetChanged()
                        }
                    }
                }
            } catch (_: TimeoutCancellationException) {
                if (scanDialog?.isShowing == true) toast("انتهى البحث. اضغط على جهاز ظاهر للاتصال أو أعد البحث.")
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { toast("تعذّر البحث: ${e.message ?: "خطأ Bluetooth"}") }
        }
    }

    private fun connectToRadio(advertisement: com.juul.kable.Advertisement, name: String) {
        scope.launch {
            try {
                status.text = "● جارٍ الاتصال..."
                radioClient?.disconnect()
                val client = RadioClient.Builder()
                    .transport(BleTransport(Peripheral(advertisement), address = advertisement.identifier.toString()))
                    .storage(SqlDelightStorageProvider(baseDir = filesDir.absolutePath))
                    .build()
                client.connect()
                radioClient = client
                connectedName = name
                status.text = "● متصل: $name"
                toast("تم الاتصال بالراديو. يمكنك الآن إرسال الرسائل عبر LoRa.")
                receiveJob?.cancel()
                receiveJob = scope.launch {
                    client.packets.collect { packet ->
                        val decoded = packet.decoded
                        if (decoded.portnum == PortNum.TEXT_MESSAGE_APP) {
                            val text = decoded.payload.toByteArray().toString(Charsets.UTF_8)
                            if (text.isNotBlank()) addMessage(text, false, true)
                        }
                    }
                }
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) {
                radioClient = null
                status.text = "● غير متصل"
                toast("فشل الاتصال: ${e.message ?: "تحقق من الراديو والاقتران"}")
            }
        }
    }

    private fun disconnectRadio() {
        scope.launch {
            receiveJob?.cancel(); receiveJob = null
            radioClient?.disconnect(); radioClient = null
            connectedName = ""
            status.text = "● محلي مشفّر"
            toast("تم قطع الاتصال")
        }
    }

    private fun sendMessage() {
        val message = input.text.toString().trim()
        if (message.isEmpty()) return
        val client = radioClient
        if (client == null) {
            addMessage(message, true, true)
            input.setText()
            toast("حُفظت محلياً فقط. اتصل براديو Meshtastic لإرسالها.")
            return
        }
        if (message.toByteArray(Charsets.UTF_8).size > 220) {
            toast("الرسالة طويلة. اختصرها لتناسب حد حزمة الراديو."); return
        }
        scope.launch {
            try {
                val handle = client.sendText(message)
                addMessage(message, true, true)
                input.setText("")
                toast("أُرسلت إلى الراديو؛ يجري انتظار تأكيد الشبكة.")
                val outcome = handle.await()
                toast("حالة الإرسال: $outcome")
            } catch (e: Exception) {
                toast("لم يتم الإرسال: ${e.message ?: "خطأ اتصال"}")
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 410) {
            if (grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) startBleScan()
            else toast("يجب السماح بصلاحيات Bluetooth للبحث عن الراديو")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(16, 13, 28)
        window.navigationBarColor = Color.rgb(16, 13, 28)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(10))
            setBackgroundColor(Color.rgb(16, 13, 28))
        }
        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(4), dp(8), dp(4), dp(12)) }
        header.addView(label("مجانين  •  MAJANIN", 23f, Color.WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))
        status = label("● محلي مشفّر", 12f, Color.rgb(74, 222, 128), true)
        header.addView(status); page.addView(header)
        memberInfo = label("", 14f, Color.rgb(196, 181, 253), true).apply {
            setPadding(dp(12), dp(12), dp(12), dp(12)); background = bg(Color.rgb(31, 26, 47), dp(16))
            setOnClickListener { showMembersDialog() }
        }
        loadMembers(); refreshMembers(); page.addView(memberInfo)
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(8), 0, dp(4)) }
        val bluetooth = Button(this).apply { text = "بحث وربط راديو LoRa"; setOnClickListener { requestBlePermissionsAndScan() } }
        bluetooth.backgroundTintList = android.content.res.ColorStateList.valueOf(purple); bluetooth.setTextColor(Color.WHITE)
        actions.addView(bluetooth, LinearLayout.LayoutParams(0, dp(48), 1f))
        val add = Button(this).apply { text = "＋ صديق"; setOnClickListener { showMembersDialog() } }
        actions.addView(add)
        val disconnect = Button(this).apply { text = "قطع"; setOnClickListener { disconnectRadio() } }
        actions.addView(disconnect); page.addView(actions)
        messages = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll = ScrollView(this).apply { isFillViewport = true; addView(messages) }
        page.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(8); bottomMargin = dp(10) })
        if (prefs.getString("messages", "[]") == "[]") {
            addMessage("أهلاً بك في مجانين 👋", false)
            addMessage("ابحث عن راديو Meshtastic متوافق عبر Bluetooth لبدء المراسلة عبر LoRa.", false)
            addMessage("الرسائل المحلية محفوظة بتشفير AES-GCM على هذا الهاتف.", false)
        } else loadMessages()
        val composer = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        input = EditText(this).apply {
            setSingleLine(true); setTextColor(Color.WHITE); setHintTextColor(Color.rgb(160, 150, 180)); hint = "اكتب رسالتك..."
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            setPadding(dp(14), dp(4), dp(14), dp(4)); background = bg(Color.rgb(38, 33, 52), dp(24))
        }
        composer.addView(input, LinearLayout.LayoutParams(0, dp(52), 1f))
        val send = Button(this).apply { text = "إرسال"; setTextColor(Color.WHITE); backgroundTintList = android.content.res.ColorStateList.valueOf(purple); setOnClickListener { sendMessage() } }
        composer.addView(send, LinearLayout.LayoutParams(-2, dp(52)).apply { marginStart = dp(8) })
        page.addView(composer); setContentView(page)
    }

    override fun onDestroy() {
        scanJob?.cancel(); receiveJob?.cancel()
        val client = radioClient
        radioClient = null
        scope.launch { try { client?.disconnect() } finally { scope.cancel() } }
        super.onDestroy()
    }
}
