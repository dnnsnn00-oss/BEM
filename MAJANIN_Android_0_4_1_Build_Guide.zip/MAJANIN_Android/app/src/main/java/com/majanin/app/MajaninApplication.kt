package com.majanin.app

import android.app.Application
import org.meshtastic.sdk.storage.sqldelight.AndroidContextHolder

class MajaninApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        AndroidContextHolder.context = applicationContext
    }
}
